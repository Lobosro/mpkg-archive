#!/bin/bash
set -e

mkdir -p 
    /etc/apk 
    /var/lib/apk 
    /var/cache/apk 
    /tmp

chmod 1777 /tmp

echo "apk-tools: directories created."
